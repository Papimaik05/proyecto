<footer>
<div id="footer">
    <div id="menuFooter">
        <div id="redes-sociales">
            <div class="ops-v">
                <a href="https://media.biobiochile.cl/wp-content/uploads/2019/05/bikini-bottom.jpeg">
                <img src="img/twitter.png" alt="twitter"> 
                </a>
                &nbsp; &nbsp;
                <a href="https://www.facebook.com/profile.php?id=100088652318580">
                <img src="img/facebook.png" alt="facebook">
                </a>
                &nbsp; &nbsp;
                <a href="https://www.instagram.com/amigosmarinos_oficial/?next=%2Famigosmarinos_oficial%2F">
                <img src="img/instagram.png" alt="instagram">
                </a>
                &nbsp; &nbsp;
                <a href="https://www.youtube.com/watch?v=_Q5YWM2I9_U&t=5889s&ab_channel=M%C3%BAsicadelMundo">
                <img src="img/youtube.png" alt="youtube">
                </a>
            </div>
        </div>

        <div id="copyright">
            <p>Copyright 2023©</p>
            <p>Todos los derechos reservados</p>
        </div>
    </div>
</div>
</footer>